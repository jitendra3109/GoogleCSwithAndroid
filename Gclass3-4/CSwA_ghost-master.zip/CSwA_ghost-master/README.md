# Unit 3 & 4: Ghost

This project is developed as a part of [Applied CS with Android](https://cswithandroid.withgoogle.com/) course. 

Each commit in this repo covers a specific step of the Unit(s). 

